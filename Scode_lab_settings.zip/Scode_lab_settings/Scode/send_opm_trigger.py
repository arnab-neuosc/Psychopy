from psychopy import core
def send_ttl_trigger(cfgTrigger, cfgExp, code, cfgEyelink, eyelinkMsg):
	timepoint = core.getTime()  # Get the current time
	return timepoint



