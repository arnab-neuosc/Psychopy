

def setup_datapixx(cfgExp, cfgScreen):
	pass

