def ms2sec(input_arg):
 
    output_arg = input_arg * 0.001
    return output_arg
